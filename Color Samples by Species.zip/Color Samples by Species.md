```python
import  os
os.getcwd() #获取当前工作目录路径
```




    '/mnt/c/Users/Files/Python_Project'




```python
# To process data.
import pandas as pd
import numpy as np
# To plot.
from pylab import *
from plotnine import *
```


```python
df = pd.read_csv('/mnt/c/Users/Files/10x/1223/gem_classification.csv')
```


```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>barcode</th>
      <th>GRCh38</th>
      <th>mm10</th>
      <th>call</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>AAACCCAAGCCGATTT</td>
      <td>1910</td>
      <td>22</td>
      <td>GRCh38</td>
    </tr>
    <tr>
      <th>1</th>
      <td>AAACCCACATGAGGGT</td>
      <td>580</td>
      <td>16</td>
      <td>GRCh38</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAACCCAGTCCAGCAC</td>
      <td>1762</td>
      <td>43</td>
      <td>GRCh38</td>
    </tr>
    <tr>
      <th>3</th>
      <td>AAACCCATCGAATGCT</td>
      <td>1371</td>
      <td>25</td>
      <td>GRCh38</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AAACGAAAGCTAATCC</td>
      <td>1929</td>
      <td>37</td>
      <td>GRCh38</td>
    </tr>
  </tbody>
</table>
</div>




```python
# geom_point. Reorder GelBead_TrueSeq by Reads.
(ggplot(df, aes(x = 'GRCh38', y = 'mm10', color = 'factor(call)' ) )
+ geom_point()
#+ scale_alpha_continuous(range=(1,100))
+ labs(x='GRCh38 UMI counts', y='mm10 UMI counts', title = "Cell UMI Counts")
+ theme_bw()
+ theme(panel_grid=element_blank())
)
```


    
![png](output_4_0.png)
    





    <ggplot: (8757144486831)>


